<?php
require_once('./config.php');

if (!isset($_SESSION['cust_id'])) {
    header("Location: customer_login.php");
    exit();
}

require_once('inc/header.php');

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['product_id']) && isset($_POST['quantity'])) {
        $product_id = intval($_POST['product_id']);
        $quantity = intval($_POST['quantity']);

        if (isset($_SESSION['cart'][$product_id])) {
            $_SESSION['cart'][$product_id] += $quantity;
        } else {
            $_SESSION['cart'][$product_id] = $quantity;
        }
    }

    if (isset($_POST['remove_product_id'])) {
        $remove_product_id = intval($_POST['remove_product_id']);
        unset($_SESSION['cart'][$remove_product_id]);
    }
}

$cart_items = [];
if (!empty($_SESSION['cart'])) {
    $product_ids = implode(',', array_keys($_SESSION['cart']));
    $query = "SELECT * FROM product WHERE product_id IN ($product_ids)";
    $result = $db->conn->query($query);

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $row['quantity'] = $_SESSION['cart'][$row['product_id']];
            $cart_items[] = $row;
        }
    } else {
        echo "Error: " . $db->conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    </head>
<body class="layout-top-nav layout-fixed layout-navbar-fixed dark-mode text-light" style="height: auto;">
<div class="wrapper">
<body>
    <?php require_once('inc/topBarNav.php'); ?>  <!-- Include navigation bar -->

    <div class="content-wrapper pt-3">
        <section class="content">
            <div class="container">
                <h1 class="text-center">Shopping Cart</h1>
                <?php if (!empty($cart_items)): ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Total</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($cart_items as $item): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                    <td>RM <?php echo number_format($item['product_price'], 2); ?></td>
                                    <td><?php echo intval($item['quantity']); ?></td>
                                    <td>RM <?php echo number_format($item['product_price'] * $item['quantity'], 2); ?></td>
                                    <td>
                                        <form action="cart.php" method="post">
                                            <input type="hidden" name="remove_product_id" value="<?php echo $item['product_id']; ?>">
                                            <button type="submit" class="btn btn-danger btn-sm">Remove</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <div class="d-flex justify-content-end">
                        <a href="checkout.php" class="btn btn-primary">Proceed to Checkout</a>
                    </div>
                <?php else: ?>
                    <p class="text-center">Your cart is empty.</p>
                <?php endif; ?>
            </div>
        </section>
    </div>


</div>
<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
