<?php
// Include the configuration file which starts the session
require_once('./config.php');

// Check if the session variable is set
if (!isset($_SESSION['cust_id'])) {
    // Use JavaScript to redirect to the login page
    echo '<script type="text/javascript">
            window.location = "customer_login.php";
          </script>';
    exit();
}

// Retrieve customer details
$cust_id = $_SESSION['cust_id'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hss_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare and execute the query
$stmt = $conn->prepare("SELECT cust_name, cust_email, cust_contact FROM customer WHERE cust_id = ?");
$stmt->bind_param("i", $cust_id);
$stmt->execute();
$stmt->bind_result($cust_name, $cust_email, $cust_contact);
$stmt->fetch();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hair Salon Appointment Form</title>
    <style>
        body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        margin: 20px;
        }
    .container {
        max-width: 1000px;
        margin: 0 auto; /* Center the container horizontally */
        padding: 0 20px; /* Optional: Add padding if needed */
        box-sizing: border-box; /* Ensure padding is included in the width */
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        .form-group button {
            padding: 10px 15px;
            background-color: #5cb85c;
            color: white;
            border: none;
            cursor: pointer;
        }
        .form-group button:hover {
            background-color: #4cae4c;
        }
        .message {
            margin-bottom: 15px;
            padding: 10px;
            border: 2px solid #AAFF00;
            background-color: #228B22;
        }
        .disabled {
            background-color: #ddd;
            color: #aaa;
            cursor: not-allowed;
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('schedule_date').addEventListener('change', function() {
                var schedule_date = this.value;
                if (schedule_date) {
                    fetchBookedSlots(schedule_date);
                }
            });
        });

        function fetchBookedSlots(schedule_date) {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'fetch_booked_slots.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var response = JSON.parse(xhr.responseText);
                    updateForm(response.bookedSlots, response.bookeddoctors);
                }
            };
            xhr.send('schedule_date=' + encodeURIComponent(schedule_date));
        }

        function updateForm(bookedSlots, bookeddoctors) {
            var timeSelect = document.getElementById('schedule_time');
            var doctorSelect = document.getElementById('doctors_id');

            // Reset all options
            for (var i = 0; i < timeSelect.options.length; i++) {
                timeSelect.options[i].disabled = false;
                timeSelect.options[i].classList.remove('disabled');
            }
            for (var i = 0; i < doctorSelect.options.length; i++) {
                doctorSelect.options[i].disabled = false;
                doctorSelect.options[i].classList.remove('disabled');
            }

            // Disable booked time slots
            bookedSlots.forEach(function(time) {
                for (var i = 0; i < timeSelect.options.length; i++) {
                    if (timeSelect.options[i].value === time) {
                        timeSelect.options[i].disabled = true;
                        timeSelect.options[i].classList.add('disabled');
                    }
                }
            });

            // Disable booked doctors
            bookeddoctors.forEach(function(doctor) {
                for (var i = 0; i < doctorSelect.options.length; i++) {
                    if (doctorSelect.options[i].value === doctor.toString()) {
                        doctorSelect.options[i].disabled = true;
                        doctorSelect.options[i].classList.add('disabled');
                    }
                }
            });
        }
    </script>
</head>
<body>
<div class="container">
    <h1>Book an Appointment</h1>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "hss_db";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("<div class='message'>Connection failed: " . $conn->connect_error . "</div>");
        }

        $schedule_date = $_POST['schedule_date'];
        $schedule_time = $_POST['schedule_time'];
        $doctors_id = $_POST['doctors_id'];
        $services = $_POST['services'];

        // Using prepared statements to prevent SQL injection
        $stmt = $conn->prepare("INSERT INTO appointment_list (cust_id, cust_name, contact_no, email, schedule_date, schedule_time, doctors_id, status, appointment_total, date_created) VALUES (?, ?, ?, ?, ?, ?, ?, 0, 0, NOW())");
        $stmt->bind_param("isssssi", $cust_id, $cust_name, $cust_contact, $cust_email, $schedule_date, $schedule_time, $doctors_id);

        if ($stmt->execute()) {
            $appointment_id = $stmt->insert_id;
            $stmt->close();

            // Insert into appointment_service
            $stmt_service = $conn->prepare("INSERT INTO appointment_service (appointment_id, service_id, cost) VALUES (?, ?, 0)");
            foreach ($services as $service_id) {
                $stmt_service->bind_param("ii", $appointment_id, $service_id);
                $stmt_service->execute();
            }
            $stmt_service->close();

            echo "<div class='message'>Appointment booked successfully!</div>";
        } else {
            echo "<div class='message'>Error: " . $stmt->error . "</div>";
        }

        $conn->close();
    }
    ?>
    <form action="" method="post">
        <div class="form-group">
            <label for="cust_name">Full Name</label>
            <input type="text" id="cust_name" name="cust_name" value="<?php echo $cust_name; ?>" readonly>
        </div>
        <div class="form-group">
            <label for="contact_no">Contact Number</label>
            <input type="text" id="contact_no" name="contact_no" value="<?php echo $cust_contact; ?>" readonly>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" value="<?php echo $cust_email; ?>" readonly>
        </div>
        <div class="form-group">
            <label for="schedule_date">Preferred Date</label>
            <input type="date" id="schedule_date" name="schedule_date" required>
        </div>
        <div class="form-group">
            <label for="schedule_time">Preferred Time</label>
            <select id="schedule_time" name="schedule_time" required>
                <option value="09:00">09:00 AM</option>
                <option value="10:00">10:00 AM</option>
                <option value="11:00">11:00 AM</option>
                <option value="12:00">12:00 PM</option>
                <option value="13:00">01:00 PM</option>
                <option value="14:00">02:00 PM</option>
                <option value="15:00">03:00 PM</option>
                <option value="16:00">04:00 PM</option>
                <option value="17:00">05:00 PM</option>
                <option value="18:00">06:00 PM</option>
            </select>
        </div>
        <div class="form-group">
            <label for="doctors_id">Preferred Doctors</label>
            <select id="doctors_id" name="doctors_id" required>
                <option value="1">Dr.Kuppusamy</option>
                <option value="2">Dr.Farul</option>
                <option value="3">Dr.Ali</option>
                <option value="4">Dr.Sophea</option>
                <option value="5">Dr.Muthukumari</option>
                <option value="6">Dr.Kamil</option>
                <option value="7">Dr.Wen Jia</option>
                <option value="8">Dr.Afham</option>
            </select>
        </div>
        </div>
        <div class="form-group">
        <label for="services">Services Required</label>
        <select id="services" name="services[]" multiple required>
            <option value="1">General Consultation</option>
            <option value="2">Health Check-Up</option>
            <option value="3">Home Visit Service</option>
            <option value="4">Private Doctor Service</option>
            <option value="5">Health Workshops</option>
            <option value="6">Vaccination Service</option>
        </select>
         </div>
        <div class="form-group">
            <button type="submit">Book Appointment</button>
        </div>
    </form>
</div>
</body>
</html>
