<?php
function updateAppointmentStatus($appointment_id, $status, $message) {
    // Database connection
    $conn = new mysqli("localhost", "username", "password", "database");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare the SQL statement
    $stmt = $conn->prepare("UPDATE appointment_list SET status = ?, notification_status = 1, notification_message = ?, date_updated = NOW() WHERE appointment_id = ?");
    $stmt->bind_param("isi", $status, $message, $appointment_id);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Appointment status updated successfully.";
    } else {
        echo "Error updating appointment status: " . $stmt->error;
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}

// Example usage
updateAppointmentStatus(1, 1, "Your appointment has been confirmed.");
?>
