<?php require_once('../config.php'); ?>

<?php
// Generate random data for June 2024 (30 days)
$case_data_array = [];
$dates = [];
$case_numbers = [];
for ($day = 1; $day <= 30; $day++) {
    $date = "2024-06-" . str_pad($day, 2, '0', STR_PAD_LEFT);
    $cases = rand(5, 20); // Random number of cases between 5 and 20
    $case_data_array[] = ['case_date' => $date, 'case_count' => $cases];
    $dates[] = $date;
    $case_numbers[] = $cases;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to <?php echo $_settings->info('name') ?></title>
    <!-- Include necessary CSS stylesheets -->
    <link rel="stylesheet" href="path/to/bootstrap.min.css">
    <!-- Include Chart.js library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .chart-container {
            position: relative;
            width: 100%;
            height: 400px;
        }
    </style>
</head>
<body>
    <h1>Welcome to <?php echo $_settings->info('name') ?></h1>
    
    <hr class="border-info">
    <div class="row">
        <div class="col-12 col-sm-12 col-md-6 col-lg-3">
            <div class="info-box bg-light shadow">
                <span class="info-box-icon bg-info elevation-1"><i class="fas fa-th-list"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">All Services</span>
                    <span class="info-box-number text-right">
                        <?php echo $conn->query("SELECT * FROM `service_list` where status = 1")->num_rows; ?>
                    </span>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-12 col-md-6 col-lg-3">
            <div class="info-box bg-light shadow">
                <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-calendar-day"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Pending Request</span>
                    <span class="info-box-number text-right">
                        <?php echo $conn->query("SELECT * FROM `appointment_list` where `status` = 0")->num_rows; ?>
                    </span>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-12 col-md-6 col-lg-3">
            <div class="info-box bg-light shadow">
                <span class="info-box-icon bg-info elevation-1"><i class="fas fa-calendar-day"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Verified Appointment</span>
                    <span class="info-box-number text-right">
                        <?php echo $conn->query("SELECT * FROM `appointment_list` where `status` = 1")->num_rows; ?>
                    </span>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-12 col-md-12 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Case Data Chart for November</h3>
                </div>
                <div class="card-body">
                    <div class="chart-container">
                        <canvas id="caseChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', (event) => {
            // Random Case Data for Chart
            const caseData = <?php echo json_encode($case_data_array); ?>;
            const labels = <?php echo json_encode($dates); ?>;
            const data = <?php echo json_encode($case_numbers); ?>;

            const ctx = document.getElementById('caseChart').getContext('2d');
            const caseChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Number of Cases',
                        data: data,
                        fill: false,
                        borderColor: 'rgba(75, 192, 192, 1)', // Line color
                        tension: 0.1,
                        borderWidth: 2
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                stepSize: 1
                            }
                        }
                    },
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        });
    </script>
</body>
</html>
