<?php
require_once('../../config.php');

if(isset($_GET['id'])){
    $appointment_id = $_GET['id'];
    
    // Fetch appointment  details including doctors information
    $qry = $conn->query("SELECT al.*, s.doctors_name
                         FROM `appointment_list` al 
                         JOIN `doctors` s ON al.doctors_id = s.doctors_id 
                         WHERE al.appointment_id = $appointment_id");

    if($qry->num_rows > 0){
        $res = $qry->fetch_assoc();
        // Extract appointment  details into variables
        extract($res);
    }
}
?>
<style>
    #uni_modal .modal-footer {
        display: none !important;
    }
</style>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-6">
            <dl>
                <dt class="text-muted">Full Name</dt>
                <dd class='pl-4 fs-4 fw-bold'><?= isset($cust_name) ? $cust_name : '' ?></dd>
                <dt class="text-muted">Email</dt>
                <dd class='pl-4 fs-4 fw-bold'><?= isset($email) ? $email : '' ?></dd>
                <dt class="text-muted">Contact</dt>
                <dd class='pl-4 fs-4 fw-bold'><?= isset($contact_no) ? $contact_no : '' ?></dd>
            </dl>
        </div>
        <div class="col-md-6">
            <dl>
                <dt class="text-muted">Schedule</dt>
                <dd class='pl-4 text-dark'>
                    <p class=""><small><?= isset($schedule_date) && isset($schedule_time) ? date("M d, Y", strtotime($schedule_date)) . ' ' . date("h:i A", strtotime($schedule_time)) : '' ?></small></p>
                </dd>
                <dt class="text-muted">Status</dt>
                <dd class='pl-4 text-dark'>
                    <?php
                    if(isset($status)){
                        switch($status){
                            case '1':
                                echo "<span class='badge badge-primary badge-pill'>Verified</span>";
                                break;
                            case '2':
                                echo "<span class='badge badge-success bg-primary badge-pill'>Done</span>";
                                break;
                            case '0':
                                echo "<span class='badge badge-light badge-pill text-dark'>Pending</span>";
                                break;
                            case '3':
                                echo "<span class='badge badge-danger badge-pill'>Rejected</span>";
                                break;
                        }
                    }
                    ?>
                </dd>
                <!-- Display doctors's name and possibly image -->
                <?php if(isset($doctors_name)): ?>
                <dt class="text-muted">doctors</dt>
                <dd class='pl-4 text-dark'>
                    <span class="doctors-name"><?= $doctors_name ?></span>
                </dd>
                <?php endif; ?>
            </dl>
        </div>
    </div>
    <div class="row">
        <table class="table table-striped table-hover table-bordered">
            <colgroup>
                <col width="100%">
            </colgroup>
            <thead>
                <tr>
                    <th class="text-center px-2 py-1">Service</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                // Fetch services related to this appointment 
                $appointment  = $conn->query("SELECT s.service_name 
                                            FROM `appointment_service` a 
                                            INNER JOIN `service_list` s ON a.service_id = s.service_id 
                                            WHERE a.appointment_id = '{$appointment_id}'");

                while($row = $appointment ->fetch_assoc()): ?>
                    <tr>
                        <td class="text-center px-2 py-1"><?= $row['service_name'] ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
            <tfoot>
                <tr>
                </tr>
            </tfoot>
        </table>
    </div>
    <div class="col-12 text-right">
        <button class="btn btn-flat btn-sm btn-dark" type="button" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
    </div>
</div>
