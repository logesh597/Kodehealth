<?php
require_once('../../config.php');

if(isset($_GET['id']) && is_numeric($_GET['id'])){
    $id = (int)$_GET['id']; // Casting to integer to prevent potential XSS or SQL injection
    
    $qry = $conn->prepare("SELECT * FROM `doctors` WHERE doctors_id = ?");
    $qry->bind_param("i", $id); // Binding parameter as integer
    $qry->execute();
    $result = $qry->get_result();
    
    if($result->num_rows > 0){
        $res = $result->fetch_assoc(); // Fetching the row as associative array
        
        // Assigning values to variables
        $doctors_name = $res['doctors_name'] ?? 'N/A';
        $doctors_position = $res['doctors_position'] ?? 'N/A';
        $doctors_description = $res['doctors_description'] ?? 'N/A';
        $doctors_image = $res['doctors_image'] ?? '';
        
    } else {
        echo "<h4>No doctors found with the provided ID.</h4>";
        exit;
    }
} else {
    echo "<h4>No valid ID provided.</h4>";
    exit;
}
?>
<div class="container-fluid">
    <div class="form-group">
        <label for="" class="control-label">Doctor Name</label>
        <p><?php echo $doctors_name; ?></p>
    </div>
    <div class="form-group">
        <label for="" class="control-label">Position</label>
        <p><?php echo $doctors_position; ?></p>
    </div>
    <div class="form-group">
        <label for="" class="control-label">Description</label>
        <p><?php echo $doctors_description; ?></p>
    </div>
    
</div>
