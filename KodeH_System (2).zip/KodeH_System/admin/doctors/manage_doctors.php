<?php
require_once('../../config.php');
if(isset($_GET['id'])){
    $qry = $conn->query("SELECT * FROM `doctors` where doctors_id = '{$_GET['id']}'");
    if($qry->num_rows > 0){
        $res = $qry->fetch_array();
        foreach($res as $k => $v){
            if(!is_numeric($k))
            $$k = $v;
        }
    }
}
?>
<div class="container-fluid">
    <form action="" id="doctors-form">
        <input type="hidden" name="doctors_id" value="<?php echo isset($doctors_id) ? $doctors_id : '' ?>">
        <div class="form-group">
            <label for="" class="control-label">Doctor Name</label>
            <input type="text" name="doctors_name" id="doctors_name" class="form-control form-control-border" placeholder="Doctors Name" value ="<?php echo isset($doctors_name) ? $doctors_name : '' ?>" required>
        </div>
        <div class="form-group">
            <label for="" class="control-label">Position</label>
            <input type="text" name="doctors_position" id="doctors_position" class="form-control form-control-border" placeholder="Position" value ="<?php echo isset($doctors_position) ? $doctors_position : '' ?>" required>
        </div>
        <div class="form-group">
            <label for="" class="control-label">Description</label>
            <textarea rows="3" name="doctors_description" id="doctors_description" class="form-control form-control-border" placeholder="Write the doctors description here." required><?php echo isset($doctors_description) ? $doctors_description : '' ?></textarea>
        </div>
        <div class="form-group">
            <label for="" class="control-label">Doctor Image</label>
            <input type="file" name="doctors_image" id="doctors_image" class="form-control form-control-border">
        </div>
    </form>
</div>

<script>
    $(function(){
        $('#uni_modal #doctors-form').submit(function(e){
            e.preventDefault();
            var _this = $(this)
            $('.pop-msg').remove()
            var el = $('<div>')
                el.addClass("pop-msg alert")
                el.hide()
            start_loader();
            $.ajax({
                url:_base_url_+"classes/Master.php?f=save_doctors",
                data: new FormData($(this)[0]),
                cache: false,
                contentType: false,
                processData: false,
                method: 'POST',
                type: 'POST',
                dataType: 'json',
                error:err=>{
                    console.log(err)
                    alert_toast("An error occurred",'error');
                    end_loader();
                },
                success:function(resp){
                    if(resp.status == 'success'){
                        location.reload();
                    }else if(!!resp.msg){
                        el.addClass("alert-danger")
                        el.text(resp.msg)
                        _this.prepend(el)
                    }else{
                        el.addClass("alert-danger")
                        el.text("An error occurred due to unknown reasons.")
                        _this.prepend(el)
                    }
                    el.show('slow')
                    end_loader();
                }
            })
        })
    })
</script>

