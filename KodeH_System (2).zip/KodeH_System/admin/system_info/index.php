<?php if($_settings->chk_flashdata('success')): ?>
<script>
	alert_toast("<?php echo $_settings->flashdata('success') ?>",'success')
</script>
<?php endif;?>



<div class="col-lg-12">
    <div class="card card-outline card-primary">
        <div class="card-header">
            <h5 class="card-title">System Information</h5>
        </div>
        <div class="card-body">
            <form action="" id="system-frm">
                <div id="msg" class="form-group"></div>
                <div class="form-group">
                    <label for="name" class="control-label">System Name</label>
                    <input type="text" class="form-control form-control-sm" name="name" id="name" value="<?php echo $_settings->info('name') ?>">
                </div>
                <div class="form-group">
                    <label for="short_name" class="control-label">System Short Name</label>
                    <input type="text" class="form-control form-control-sm" name="short_name" id="short_name" value="<?php echo $_settings->info('short_name') ?>">
                </div>
                             
                    <legend>Kode  Information</legend>
                    <div class="form-group">
                        <label for="email" class="control-label">Kode Email</label>
                        <input type="email" class="form-control form-control-sm" name="email" id="email" value="<?php echo $_settings->info('email') ?>">
                    </div>
                    <div class="form-group">
                        <label for="contact" class="control-label">Kode Contact #</label>
                        <input type="text" class="form-control form-control-sm" name="contact" id="contact" value="<?php echo $_settings->info('contact') ?>">
                    </div>
                    <div class="form-group">
                        <label for="address" class="control-label">Address</label>
                        <textarea rows="3" class="form-control form-control-sm" name="address" id="address" style="resize:none"><?php echo $_settings->info('address') ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="contact" class="control-label">Kode Open Time</label>
                        <div class="row">
                            <div class="form-group col-6">
                                <input type="time" class="form-control form-control-sm" name="from_time" id="from_time" value="<?php echo $_settings->info('from_time') ?>">
                            </div>
                            <div class="form-group col-6">
                                <input type="time" class="form-control form-control-sm" name="to_time" id="to_time" value="<?php echo $_settings->info('to_time') ?>">
                            </div>
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
        <div class="card-footer">
            <div class="col-md-12">
                <div class="row">
                    <button type="submit" class="btn btn-sm btn-primary" form="system-frm">Update</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    

    $(document).ready(function(){
        $('.summernote').summernote({
            height: 200,
            toolbar: [
                [ 'style', [ 'style' ] ],
                [ 'font', [ 'bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear'] ],
                [ 'fontname', [ 'fontname' ] ],
                [ 'fontsize', [ 'fontsize' ] ],
                [ 'color', [ 'color' ] ],
                [ 'para', [ 'ol', 'ul', 'paragraph', 'height' ] ],
                [ 'table', [ 'table' ] ],
                [ 'view', [ 'undo', 'redo', 'fullscreen', 'codeview', 'help' ] ]
            ]
        });

        $('#system-frm').submit(function(e) {
            e.preventDefault(); // Prevent default form submission
            var formData = new FormData(this); // Prepare the form data
            
            $.ajax({
                url: 'update_system_info.php',  // The script to handle the form data
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    // Handle the response (e.g., success message or reload page)
                    alert('System information updated successfully!');
                    window.location.reload();  // Reload the page to see updates
                },
                error: function() {
                    alert('Error updating data');
                }
            });
        });
    });
</script>
