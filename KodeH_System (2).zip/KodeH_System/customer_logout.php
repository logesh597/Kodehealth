<?php
include 'config.php'; // This includes session_start()

// Destroy session
session_unset(); 
session_destroy();

// Redirect to index page
header("Location: index.php?message=logout");
exit();
?>
