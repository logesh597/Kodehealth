<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hss_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$schedule_date = $_POST['schedule_date'];

$sql = "SELECT schedule_time, doctors_id FROM appointment_list WHERE schedule_date = ? AND status = 1"; // status 1 means confirmed by admin
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $schedule_date);
$stmt->execute();
$result = $stmt->get_result();

$bookedSlots = [];
$bookeddoctors = [];

while ($row = $result->fetch_assoc()) {
    $bookedSlots[] = $row['schedule_time'];
    $bookeddoctors[] = $row['doctors_id'];
}

$stmt->close();
$conn->close();

echo json_encode(['bookedSlots' => $bookedSlots, 'bookeddoctors' => $bookeddoctors]);
?>
