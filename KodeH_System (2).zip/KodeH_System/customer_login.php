<?php
include 'config.php'; // Assuming session_start() is called within config.php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cust_username = mysqli_real_escape_string($conn, $_POST['cust_username']);
    $cust_password = mysqli_real_escape_string($conn, $_POST['cust_password']);

    $sql = "SELECT * FROM customer WHERE cust_username='$cust_username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $hashed_password = $row['cust_password'];

        if (password_verify($cust_password, $hashed_password)) {
            $_SESSION['cust_id'] = $row['cust_id'];
            $_SESSION['cust_username'] = $row['cust_username'];
            header("Location: index.php?message=login_success"); // Redirect with message parameter
            exit();
        } else {
            echo "Invalid username or password";
        }
    } else {
        echo "Invalid username or password";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        /* Center the form on the page */
        body, html {
            height: 100%;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            background-image: url('uploads/KS_cover.jpg'); /* Path to your background image */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            font-family: Arial, sans-serif; /* Example: Use a commonly available font */
        }

        /* Bordered form */
        form {
            border: 3px solid #f1f1f1;
            width: 100%;
            max-width: 400px;
            background-color: white;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        /* Full-width inputs */
        input[type=text], input[type=password] {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        /* Show/hide password toggle */
        .password-toggle {
            position: relative;
        }

        .password-toggle input[type=password] {
            padding-right: 30px; /* Space for the toggle button */
        }

        .password-toggle .toggle-password {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
        }

        /* Set a style for all buttons */
        button {
            background-color: #007BFF;
            color: black;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
        }

        /* Add a hover effect for buttons */
        button:hover {
            opacity: 0.8;
        }

        /* Extra style for the signup button */
        .signupbtn {
            width: 100%;
            padding: 14px 20px;
            background-color: #6C757D;
            margin-top: 8px;
        }

        /* Add padding to containers */
        .container {
            padding: 16px;
        }

        /* Change styles for span and signup button on extra small screens */
        @media screen and (max-width: 300px) {
            .signupbtn {
                width: 100%;
            }
        }
    </style>
    <script>
        // Function to toggle password visibility
        function togglePasswordVisibility() {
            var passwordField = document.getElementById("cust_password");
            var toggleButton = document.getElementById("toggleButton");

            if (passwordField.type === "password") {
                passwordField.type = "text";
                toggleButton.textContent = "Hide";
            } else {
                passwordField.type = "password";
                toggleButton.textContent = "Show";
            }
        }
    </script>
</head>
<body>
    <form method="post" action="customer_login.php">
        <h2>Login</h2>
        <div class="container">
            <label>Username:</label>
            <input type="text" name="cust_username" required>
            <label>Password:</label>
            <div class="password-toggle">
                <input type="password" name="cust_password" id="cust_password" required>
                <span class="toggle-password" id="toggleButton" onclick="togglePasswordVisibility()">Show</span>
            </div>
            <button type="submit">Login</button>
        </div>
        <div class="container" style="background-color:#f1f1f1; text-align: center;">
            <p>Don't have an account?</p>
            <button type="button" class="signupbtn" onclick="window.location.href='customer_signup.php'">Sign up here</button>
        </div>
        <div class="container" style="background-color:#f1f1f1; text-align: center;">
            <p>Login as Admin?</p>
            <button type="button" onclick="window.location.href='admin/login.php'">Login as Admin</button>
        </div>
    </form>
</body>
</html>
