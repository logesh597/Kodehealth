<?php
// Start the session
/*session_start();*/
require_once('./config.php');
require_once('inc/header.php');

// Check if the customer is logged in
if (!isset($_SESSION['cust_id'])) {
    header("Location: customer_login.php"); // Redirect to login page if not logged in
    exit();
}

// Database connection
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "hss_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve customer notifications
$cust_id = $_SESSION['cust_id']; // Use customer ID from session
$sql = "SELECT  
            appointment_id,
            schedule_date, 
            schedule_time, 
            status, 
            notification_message, 
            (SELECT GROUP_CONCAT(service_name SEPARATOR ', ') 
             FROM appointment_service 
             JOIN service_list ON appointment_service.service_id = service_list.service_id 
             WHERE appointment_service.appointment_id = appointment_list.appointment_id) AS services
        FROM appointment_list 
        WHERE cust_id = $cust_id AND notification_status = 1";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Notifications</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        /*.container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            position: relative;
        }*/
        h1 {
            text-align: center;
            color: #f9f9f9;
        }
        .card {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 20px;
            margin: 10px 0;
            background-color: #f9f9f9;
        }
        .card-header {
            font-weight: bold;
            cursor: pointer;
        }
        .card-details {
            display: none;
            margin-top: 10px;
        }
        .toggle-message {
            color: #007bff;
            text-decoration: underline;
            cursor: pointer;
            display: block;
            margin-top: 10px;
        }
        .toggle-message:hover {
            color: #0056b3;
        }
        .delete-notification {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 3px;
            float: right;
        }
        .delete-notification:hover {
            background-color: #c82333;
        }
        .back-link {
            display: block;
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 1.2em;
            text-decoration: none;
            color: #007bff;
        }
        .back-link:hover {
            color: #0056b3;
        }
        .appointment-status {
            font-weight: bold;
        }
        .appointment-status.verified {
            color: #32CD32; /* LimeGreen for Verified */
        }
        .appointment-status.rejected {
            color: #FF4500; /* OrangeRed for Rejected */
        }
    </style>
</head>
<body class="layout-top-nav layout-fixed layout-navbar-fixed dark-mode text-light" style="height: auto;">
<div class="wrapper">
<?php require_once('inc/topBarNav.php'); ?>  <!-- Include navigation bar -->
<div class="container">
    <h1><br><br>My Notifications</h1>

    <?php
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $statusClass = $row['status'] == 1 ? "verified" : "rejected";
            $statusText = $row['status'] == 1 ? "Verified" : "Rejected";
            echo "<div class='card'>";
            echo "<div class='card-header'>Your Appointment is <span class='appointment-status " . $statusClass . "'>" . $statusText . "</span></div>";
            echo "<div class='card-details'>";
            echo "<p><strong>Date:</strong> " . $row['schedule_date'] . "</p>";
            echo "<p><strong>Time:</strong> " . $row['schedule_time'] . "</p>";
            echo "<p><strong>Services:</strong> " . $row['services'] . "</p>";
            echo "<p><strong>Message:</strong> " . $row['notification_message'] . "</p>";
            echo "</div>";
            echo "<span class='toggle-message'>View Details</span>";
            echo "<form method='POST' action='delete_notification.php' style='display:inline;'>";
            echo "<input type='hidden' name='appointment_id' value='" . $row['appointment_id'] . "'>";
            echo "<button type='submit' class='delete-notification'>Delete</button>";
            echo "</form>";
            echo "</div>";
        }
    } else {
        echo "<p>No notifications available.</p>";
    }

    $conn->close();
    ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var toggleLinks = document.querySelectorAll('.toggle-message');
    toggleLinks.forEach(function(link) {
        link.addEventListener('click', function() {
            var cardDetails = this.previousElementSibling;
            if (cardDetails.style.display === 'none' || cardDetails.style.display === '') {
                cardDetails.style.display = 'block';
                this.textContent = 'Hide Details';
            } else {
                cardDetails.style.display = 'none';
                this.textContent = 'View Details';
            }
        });
    });
});
</script>

</body>
</html>
