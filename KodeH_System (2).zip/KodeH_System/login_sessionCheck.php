<?php

if (!isset($_SESSION['cust_id'])) {
    header("Location: customer_login.php");
    exit();
}
?>
