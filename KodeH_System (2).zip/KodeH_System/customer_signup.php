<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cust_name = mysqli_real_escape_string($conn, $_POST['cust_name']);
    $cust_username = mysqli_real_escape_string($conn, $_POST['cust_username']);
    $cust_contact = mysqli_real_escape_string($conn, $_POST['cust_contact']);
    $cust_email = mysqli_real_escape_string($conn, $_POST['cust_email']);
    $cust_password = mysqli_real_escape_string($conn, $_POST['cust_password']);

    // Hash the password
    $hashed_password = password_hash($cust_password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO customer (cust_name, cust_username, cust_contact, cust_email, cust_password) VALUES ('$cust_name', '$cust_username', '$cust_contact', '$cust_email', '$hashed_password')";
    
    if ($conn->query($sql) === TRUE) {
        // Redirect to login page after successful signup
        header("Location: customer_login.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sign Up</title>
    <style>
        /* Center the form on the page */
        body, html {
            height: 100%;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            background-image: url('uploads/KS_cover.jpg'); /* Path to your background image */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            font-family: Arial, sans-serif; /* Example: Use a commonly available font */
            color: #333; /* Default text color */
        }

        /* Add space around the form */
        body {
            padding-top: 50px; /* Adjust as needed */
            padding-bottom: 50px; /* Adjust as needed */
        }

        /* Bordered form */
        form {
            border: 3px solid #f1f1f1;
            width: 350px; /* Adjusted width for a wider form */
            background-color: white;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        /* Full-width inputs */
        input[type=text], input[type=password] {
            width: calc(100% - 24px); /* Adjusted width */
            padding: 12px;
            margin: 6px 0; /* Reduced margin */
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        /* Set a style for all buttons */
        button {
            background-color: #007BFF;
            color: black;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
        }

        /* Add a hover effect for buttons */
        button:hover {
            opacity: 0.8;
        }

        /* Extra style for the signup button */
        .signupbtn {
            width: 100%;
            padding: 14px 20px;
            background-color: #6C757D;
            margin-top: 8px;
        }

        /* Add padding to containers */
        .container {
            padding: 16px;
        }

        /* Change styles for span and signup button on extra small screens */
        @media screen and (max-width: 300px) {
            .signupbtn {
                width: 100%;
            }
        }

        /* Style for the title */
        h2 {
            text-align: center;
            color: #333; /* Adjust text color to ensure visibility */
        }

        /* The message box is shown when the user clicks on the password field */
        #message {
            display:none;
            background: #f1f1f1;
            color: #000;
            position: relative;
            padding: 20px;
            margin-top: 10px;
        }

        #message p {
            padding: 10px 35px;
            font-size: 18px;
        }

        /* Add a green text color and a checkmark when the requirements are right */
        .valid {
            color: green;
        }

        .valid:before {
            position: relative;
            left: -35px;
            content: "\2714"; /* Use the Unicode character code */
        }

        /* Add a red text color and an "x" icon when the requirements are wrong */
        .invalid {
            color: red;
        }

        .invalid:before {
            position: relative;
            left: -35px;
            content: "\2716"; /* Use the Unicode character code */
        }
    </style>
</head>
<body>
    <form method="post" action="customer_signup.php">
        <h2>Sign Up</h2>
        <div class="container">
            <label>Name:</label>
            <input type="text" name="cust_name" required><br>
            <label>Contact No:</label>
            <input type="text" name="cust_contact" required><br>
            <label>Email:</label>
            <input type="text" name="cust_email" required><br>
            <label>Username:</label>
            <input type="text" name="cust_username" required><br>
            <label>Password:</label>
            <input type="password" id="psw" name="cust_password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
            <input type="checkbox" onclick="togglePassword()"> Show Password<br>
            <button type="submit">Sign Up</button>
        </div>
        <div class="container" style="background-color:#f1f1f1; text-align: center;">
            <p>Already have an account? <a href="customer_login.php">Login here</a></p>
        </div>
    </form>

    <div id="message">
        <h3>Password must contain the following:</h3>
        <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
        <p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
        <p id="number" class="invalid">A <b>number</b></p>
        <p id="length" class="invalid">Minimum <b>8 characters</b></p>
    </div>

    <script>
        var myInput = document.getElementById("psw");
        var letter = document.getElementById("letter");
        var capital = document.getElementById("capital");
        var number = document.getElementById("number");
        var length = document.getElementById("length");

        // When the user clicks on the password field, show the message box
        myInput.onfocus = function() {
            document.getElementById("message").style.display = "block";
        }

        // When the user clicks outside of the password field, hide the message box
        myInput.onblur = function() {
            document.getElementById("message").style.display = "none";
        }

        // When the user starts to type something inside the password field
        myInput.onkeyup = function() {
            // Validate lowercase letters
            var lowerCaseLetters = /[a-z]/g;
            if(myInput.value.match(lowerCaseLetters)) {
                letter.classList.remove("invalid");
                letter.classList.add("valid");
            } else {
                letter.classList.remove("valid");
                letter.classList.add("invalid");
            }

            // Validate capital letters
            var upperCaseLetters = /[A-Z]/g;
            if(myInput.value.match(upperCaseLetters)) {
                capital.classList.remove("invalid");
                capital.classList.add("valid");
            } else {
                capital.classList.remove("valid");
                capital.classList.add("invalid");
            }

            // Validate numbers
            var numbers = /[0-9]/g;
            if(myInput.value.match(numbers)) {
                number.classList.remove("invalid");
                number.classList.add("valid");
            } else {
                number.classList.remove("valid");
                number.classList.add("invalid");
            }

            // Validate length
            if(myInput.value.length >= 8) {
                length.classList.remove("invalid");
                length.classList.add("valid");
            } else {
                length.classList.remove("valid");
                length.classList.add("invalid");
            }
        }

        // Toggle password visibility
        function togglePassword() {
            var x = document.getElementById("psw");
            if (x.type === "password") {
                x.type = "text";
            } else {
                x.type = "password";
            }
        }
    </script>
</body>
</html>
