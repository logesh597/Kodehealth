CREATE TABLE system_info (
  id int(30) NOT NULL,
  meta_field text NOT NULL,
  meta_value text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table system_info
--

INSERT INTO system_info (meta_field, meta_value) VALUES
('name', 'Kode Health'),
('short_name', 'KodeH'),
('logo', 'uploads/logo.png'),
('user_avatar', 'uploads/user_avatar.jpg'),
('cover', 'uploads/cover_h.jpg'),
('content', 'Array'),
('email', 'KODE.com'),
('contact', '6012-6666666'),
('from_time', '09:00'),
('to_time', '19:00'),
('address', 'Jalan Mahsuri, Bayan Baru, 11950 Bayan Lepas, Pulau Pinang');
-- --------------------------------------------------------

--
-- Table structure for table users
--

CREATE TABLE users (
  id int(50) NOT NULL,
  firstname varchar(250) NOT NULL,
  middlename text DEFAULT NULL,
  lastname varchar(250) NOT NULL,
  username text NOT NULL,
  password text NOT NULL,
  last_login datetime DEFAULT NULL,
  type tinyint(1) NOT NULL DEFAULT 0,
  status int(1) NOT NULL DEFAULT 1 COMMENT '0=not verified, 1 = verified',
  date_added datetime NOT NULL DEFAULT current_timestamp(),
  date_updated datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table users
--

INSERT INTO users (id, firstname, middlename, lastname, username, password, last_login, type, status, date_added, date_updated) VALUES
(1, 'Adminstrator', NULL, 'Admin', 'admin', '0192023a7bbd73250516f069df18b500', NULL, 1, 1, '2021-01-20 14:02:37', '2021-11-27 13:39:11'),
(3, 'John', NULL, 'Smith', 'jsmith', '1254737c076cf867dc53d60a0364f38e', NULL, 2, 1, '2021-12-01 15:30:41', '2021-12-01 15:30:42');


--


-- Table structure for table customer
CREATE TABLE customer (
  cust_id int(50) NOT NULL AUTO_INCREMENT,
  cust_name varchar(250) NOT NULL,
  cust_username text NOT NULL,
  cust_password text NOT NULL,
  cust_email text NOT NULL,
  cust_contact text NOT NULL,
  PRIMARY KEY (cust_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table customer
INSERT INTO customer (cust_id,cust_name, cust_username, cust_password,cust_email,cust_contact) VALUES
(1,'Belle', 'belle32', 'belle2112', 'belle32@gmail.com', '012-663445'),
(2,'Carmen', 'carmen44', 'carmen4040', 'carmen44@gmail.com', '017-8856639');

-- --------------------------------------------------------



-- --------------------------------------------------------

-- Table structure for table doctors
CREATE TABLE doctors (
  doctors_id int(100) NOT NULL AUTO_INCREMENT,
  doctors_name varchar(100) NOT NULL,
  doctors_position text NOT NULL,
  doctors_description text NOT NULL,
  doctors_image varchar(1050) NOT NULL,
  PRIMARY KEY (doctors_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- Dumping data for table doctors
INSERT INTO doctors (doctors_id, doctors_image, doctors_name, doctors_position, doctors_description) 
VALUES
(1, 'uploads/kup.jpg', 'Dr. Kuppusamy', 'Chief Surgeon','Dr. Kuppusamy is a pioneering leader in the medical field, renowned for her precision and innovative techniques in surgery. With decades of experience, she is dedicated to providing top-notch patient care and mentoring the next generation of surgeons. Her expertise and commitment to excellence make her a cornerstone of the medical community.'),
(2, 'uploads/far.jpeg', 'Dr. Farul', 'Resident Doctor','Dr. Farul is an enthusiastic and diligent resident, eager to expand his knowledge and skills. He is committed to learning the latest medical advancements and providing compassionate care to patients. His dedication and energy are invaluable to the team.'),
(3, 'uploads/al.jpg', 'Dr. Ali', 'Senior Physician','Dr. Ali is a highly experienced physician with a deep understanding of both traditional and modern medical practices. Her diagnostic skills and patient-focused approach have earned her great respect among colleagues and patients alike. She excels in providing comprehensive care and guidance.'),
(4, 'uploads/s.jpg', 'Dr. Sophea', 'Resident Doctor','Dr. Sophea combines her natural empathy with growing technical expertise to deliver exceptional patient care. Known for her thorough approach and attention to detail, she is steadily building a reputation as a dedicated and promising medical professional.'),
(5, 'uploads/mut.jpg', 'Dr. Muthukumari', 'Senior Consultant','Dr. Muthukumari is a seasoned consultant specializing in internal medicine. She is renowned for her ability to diagnose complex cases and provide effective treatment plans. Her years of experience and dedication to patient well-being are integral to her practice.'),
(6, 'uploads/ka.jpeg', 'Dr. Kamil', 'Cardiologist','Dr. Kamil is a highly skilled cardiologist with over a decade of experience in diagnosing and treating cardiovascular conditions. He is known for his precision, patient-centered care, and use of advanced techniques to improve outcomes for his patients.'),
(7, 'uploads/wen.jpeg', 'Dr. Wen Jia', 'Neurologist','Dr. Wen Jia is an expert neurologist with a focus on diagnosing and managing complex neurological disorders. She combines a deep understanding of brain and nervous system health with innovative treatment approaches, earning her the trust and admiration of her patients.'),
(8, 'uploads/af.jpg', 'Dr. Afham', 'Oncologist','Dr. Afham is a leading oncologist specializing in the diagnosis and treatment of cancer. With a compassionate approach and expertise in cutting-edge therapies, he provides hope and support to his patients while pursuing excellence in medical research.');


UPDATE doctors SET doctors_image = 'uploads/kup.jpg' WHERE doctors_id = 1;
UPDATE doctors SET doctors_image = 'uploads/far.jpeg' WHERE doctors_id = 2;
UPDATE doctors SET doctors_image = 'uploads/al.jpg' WHERE doctors_id = 3;
UPDATE doctors SET doctors_image = 'uploads/s.jpg' WHERE doctors_id = 4;
UPDATE doctors SET doctors_image = 'uploads/mut.jpg' WHERE doctors_id = 5;

-- ----------------------------------------------------------

-- Table structure for table appointment_list
CREATE TABLE appointment_list (
  appointment_id int(30) NOT NULL AUTO_INCREMENT,
  cust_id int(30) NOT NULL,
  cust_name text NOT NULL,
  contact_no text NOT NULL,
  email text NOT NULL,
  schedule_date date NOT NULL,
  schedule_time time NOT NULL,
  doctors_id int NOT NULL,
  status tinyint(1) NOT NULL DEFAULT 0,
  appointment_total float NOT NULL DEFAULT 0,
  date_created datetime NOT NULL DEFAULT current_timestamp(),
  date_updated datetime DEFAULT NULL,
  PRIMARY KEY (appointment_id),
  FOREIGN KEY (doctors_id) REFERENCES doctors(doctors_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table appointment_list
INSERT INTO appointment_list (cust_id, cust_name, contact_no, email, schedule_date, schedule_time, doctors_id, status, appointment_total, date_created) VALUES
(1, 'Alice', '60123456789', 'alice@gmail.com', '2024-08-15', '10:30:00', 1, 1, 30, '2024-06-12 10:30:00'),
(2, 'Catherine', '60145678901', 'catherine@gmail.com', '2024-08-15', '09:20:00', 2, 1, 29, '2024-04-18 09:20:00');

ALTER TABLE appointment_list
ADD COLUMN notification_status TINYINT(1)NOT NULL DEFAULT 0,
ADD COLUMN notification_message TEXT DEFAULT NULL;

/**ALTER TABLE appointment_list
ADD COLUMN doctors_id int NOT NULL,
ADD FOREIGN KEY (doctors_id) REFERENCES doctors(doctors_id);

UPDATE appointment_list SET doctors_id = 1 WHERE appointment_id = 1;
UPDATE appointment_list SET doctors_id = 2 WHERE appointment_id = 2;
**/

-- --------------------------------------------------------

-- Table structure for table appointment_service
CREATE TABLE appointment_service (
  appointment_id int(30) NOT NULL,
  service_id int(30) NOT NULL,
  cost float NOT NULL DEFAULT 0,
  PRIMARY KEY (appointment_id, service_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table appointment_service
INSERT INTO appointment_service (appointment_id, service_id, cost) VALUES
(1, 6, 200),
(1, 1, 80),
(1, 3, 250),
(1, 5, 300),
(2, 6, 200),
(2, 1, 80),
(2, 5, 300);

-- --------------------------------------------------------

-- Table structure for table service_list
CREATE TABLE service_list (
  service_id int(30) NOT NULL AUTO_INCREMENT,
  service_name text NOT NULL,
  description text NOT NULL,
  cost float NOT NULL DEFAULT 0,
  status tinyint(1) NOT NULL DEFAULT 1,
  date_created datetime NOT NULL DEFAULT current_timestamp(),
  date_updated datetime DEFAULT NULL ON UPDATE current_timestamp(),
      `image_url` VARCHAR(1024) NULL,  -- Allow for larger URLs

  PRIMARY KEY (service_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table service_list
INSERT INTO service_list (service_id, service_name, description, cost, status) VALUES
(1, 'General Consultation', 'Professional medical consultations for individuals and families. We provide comprehensive health assessments and tailored medical advice to address your concerns.', 500, 1),
(2, 'Health Check-Up', 'Complete health check-up service, including diagnostic tests, physical examinations, and consultations with specialists. Our goal is to ensure your well-being and identify potential health risks early.', 300, 1),
(3, 'Home Visit Service', 'Personalized medical care in the comfort of your home. Our doctors offer home visits for routine check-ups, treatment plans, and post-surgical care, ensuring convenience and quality healthcare.', 100, 1),
(4, 'Private Doctor Service', 'Hire a private doctor for dedicated care during special situations. Our doctors provide one-on-one attention, advanced diagnostic services, and tailored medical support at your location.', 800, 1),
(5, 'Health Workshops', 'Interactive health workshops led by medical professionals. These sessions cover various topics, including healthy lifestyle habits, disease prevention, and first aid techniques.', 150, 1),
(6, 'Vaccination Service', 'Professional vaccination services for individuals and groups. Our trained staff ensures a safe and comfortable experience, with a wide range of vaccines available to protect your health.', 200, 1);

-- Updating descriptions to ensure clarity and relevance to healthcare
UPDATE service_list 
SET description = 'Professional medical consultations for individuals and families. We provide comprehensive health assessments and tailored medical advice to address your concerns.' 
WHERE service_id = 1;

UPDATE service_list 
SET description = 'Complete health check-up service, including diagnostic tests, physical examinations, and consultations with specialists. Our goal is to ensure your well-being and identify potential health risks early.' 
WHERE service_id = 2;

UPDATE service_list 
SET description = 'Personalized medical care in the comfort of your home. Our doctors offer home visits for routine check-ups, treatment plans, and post-surgical care, ensuring convenience and quality healthcare.' 
WHERE service_id = 3;

UPDATE service_list 
SET description = 'Hire a private doctor for dedicated care during special situations. Our doctors provide one-on-one attention, advanced diagnostic services, and tailored medical support at your location.' 
WHERE service_id = 4;

UPDATE service_list 
SET description = 'Interactive health workshops led by medical professionals. These sessions cover various topics, including healthy lifestyle habits, disease prevention, and first aid techniques.' 
WHERE service_id = 5;

UPDATE service_list 
SET description = 'Professional vaccination services for individuals and groups. Our trained staff ensures a safe and comfortable experience, with a wide range of vaccines available to protect your health.' 
WHERE service_id = 6;

-- --------------------------------------------------------

-- Table structure for table dishes
CREATE TABLE dishes (
  dishes_id int(50) NOT NULL AUTO_INCREMENT,
  dishes_name text NOT NULL,
  dishes_description text,
  dishes_price DECIMAL(10, 2) NOT NULL,
  dishes_quantity int(200),
  PRIMARY KEY (dishes_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table dishes
INSERT INTO dishes (dishes_id, dishes_name, dishes_description, dishes_price) VALUES
(1, 'Yorkshire Lamb Patties', 'Lamb patties which melt in your mouth, and are quick and easy to make. Served hot with a crisp salad.', 14.00),
(2, 'Manchurian Chicken', 'Chicken pieces slow cooked with spring onions in our house made manchurian style sauce.', 11.00),
(3, 'Chicken Madeira', 'Chicken Madeira, like Chicken Marsala, is made with chicken, mushrooms, and a special fortified wine. But, the wines are different;', 23.00),
(4, 'Stuffed Jacket Potatoes', 'Deep fry whole potatoes in oil for 8-10 minutes or coat each potato with little oil. Mix the onions, garlic, tomatoes and mushrooms. Add yoghurt, ginger, garlic, chillies, coriander', 8.00),
(5, 'Pink Spaghetti Gamberoni', 'Spaghetti with prawns in a fresh tomato sauce. This dish originates from Southern Italy and with the combination of prawns, garlic, chilli and pasta. Garnish each with remaining tablespoon parsley.', 21.00),
(6, 'Cheesy Mashed Potato', 'Deliciously Cheesy Mashed Potato. The ultimate mash for your Thanksgiving table or the perfect accompaniment to vegan sausage casserole. Everyone will love it\'s fluffy, cheesy.', 5.00),
(7, 'Crispy Chicken Strips', 'Fried chicken strips, served with special honey mustard sauce.', 8.00),
(8, 'Lemon Grilled Chicken And Pasta', 'Marinated rosemary grilled chicken breast served with mashed potatoes and your choice of pasta.', 11.00),
(9, 'Vegetable Fried Rice', 'Chinese rice wok with cabbage, beans, carrots, and spring onions.', 5.00),
(10, 'Prawn Crackers', '12 pieces deep-fried prawn crackers', 7.00),
(11, 'Spring Rolls', 'Lightly seasoned shredded cabbage, onion and carrots, wrapped in house made spring roll wrappers, deep fried to golden brown.', 6.00),
(12, 'Buffalo Wings', 'Fried chicken wings tossed in spicy Buffalo sauce served with crisp celery sticks and Blue cheese dip.', 11.00),
(13, 'Mac N Cheese Bites', 'Served with our traditional spicy queso and marinara sauce.', 9.00),
(14, 'Signature Potato Twisters', 'Spiral sliced potatoes, topped with our traditional spicy queso, Monterey Jack cheese, pico de gallo, sour cream and fresh cilantro.', 6.00),
(15, 'Meatballs Penne Pasta', 'Garlic-herb beef meatballs tossed in our house-made marinara sauce and penne pasta topped with fresh parsley.', 10.00);

ALTER TABLE dishes
ADD COLUMN dishes_image VARCHAR(1000) DEFAULT NULL AFTER dishes_price;

UPDATE dishes SET dishes_image = 'uploads/62908867a48e4.jpg' WHERE dishes_id = 1;
UPDATE dishes SET dishes_image = 'uploads/606d7600dc54c.jpg' WHERE dishes_id = 2;
UPDATE dishes SET dishes_image = 'uploads/62908bdf2f581.jpg' WHERE dishes_id = 3;
UPDATE dishes SET dishes_image = 'uploads/62908d393465b.jpg' WHERE dishes_id = 4;
UPDATE dishes SET dishes_image = 'uploads/606d7491a9d13.jpg' WHERE dishes_id = 5;
UPDATE dishes SET dishes_image = 'uploads/606d74c416da5.jpg' WHERE dishes_id = 6;
UPDATE dishes SET dishes_image = 'uploads/606d74f6ecbbb.jpg' WHERE dishes_id = 7;
UPDATE dishes SET dishes_image = 'uploads/606d752a209c3.jpg' WHERE dishes_id = 8;
UPDATE dishes SET dishes_image = 'uploads/606d7575798fb.jpg' WHERE dishes_id = 9;
UPDATE dishes SET dishes_image = 'uploads/606d75a7e21ec.jpg' WHERE dishes_id = 10;
UPDATE dishes SET dishes_image = 'uploads/606d75ce105d0.jpg' WHERE dishes_id = 11;
UPDATE dishes SET dishes_image = 'uploads/606d765f69a19.jpg' WHERE dishes_id = 12;
UPDATE dishes SET dishes_image = 'uploads/606d768a1b2a1.jpg' WHERE dishes_id = 13;
UPDATE dishes SET dishes_image = 'uploads/606d76ad0c0cb.jpg' WHERE dishes_id = 14;
UPDATE dishes SET dishes_image = 'uploads/606d76eedbb99.jpg' WHERE dishes_id = 15;


-- --------------------------------------------------------

-- Table structure for table sales
CREATE TABLE sales (
  sales_id INT AUTO_INCREMENT PRIMARY KEY,
  dishes_id INT NOT NULL,
  dishes_quantity INT NOT NULL,
  sale_date DATE NOT NULL,
  FOREIGN KEY (dishes_id) REFERENCES dishes(dishes_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO sales (sales_id, dishes_id, dishes_quantity, sale_date) VALUES
(1, 1, 5, '2024-06-01'),
(2, 2, 3, '2024-06-02'),
(3, 1, 2, '2024-06-03'),
(4, 3, 1, '2024-06-04'),
(5, 2, 4, '2024-06-05'),
(6, 1, 7, '2024-06-06'),
(7, 4, 3, '2024-06-07'),
(8, 6, 4, '2024-06-08'),
(9, 1, 6, '2024-06-09'),
(10, 2, 3, '2024-06-10'),
(11, 3, 2, '2024-06-11'),
(12, 4, 5, '2024-06-12'),
(13, 5, 6, '2024-06-13'),
(14, 6, 4, '2024-06-14'),
(15, 2, 2, '2024-06-15'),
(16, 1, 3, '2024-06-16'),
(17, 4, 5, '2024-06-17'),
(18, 5, 8, '2024-06-18'),
(19, 5, 4, '2024-06-19'),
(20, 1, 5, '2024-06-20'),
(21, 1, 3, '2024-06-21'),
(22, 2, 7, '2024-06-22'),
(23, 1, 4, '2024-06-23'),
(24, 3, 2, '2024-06-24'),
(25, 1, 3, '2024-06-25'),
(26, 2, 5, '2024-06-26'),
(27, 1, 6, '2024-06-27'),
(28, 3, 4, '2024-06-28'),
(29, 6, 2, '2024-06-29'),
(30, 5, 4, '2024-06-30');


SELECT SUM(dishes_quantity) AS total_sales FROM sales;

SELECT dishes_id, SUM(dishes_quantity) AS total_sales 
FROM sales 
GROUP BY dishes_id;

SELECT sale_date, SUM(dishes_quantity) AS total_sales 
FROM sales 
GROUP BY sale_date;

SELECT SUM(dishes_quantity) AS total_sales 
FROM sales 
WHERE DATE(sale_date) = CURDATE();

SELECT SUM(dishes_quantity) AS total_sales 
FROM sales 
WHERE sale_date BETWEEN '2024-06-01' AND '2024-06-30';



-- --------------------------------------------------------

-- Table structure for table orders
CREATE TABLE orders (
  order_id INT AUTO_INCREMENT PRIMARY KEY,
  cust_id INT NOT NULL,
  order_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  order_status tinyint(1) NOT NULL DEFAULT 0,
  FOREIGN KEY (cust_id) REFERENCES customer(cust_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO orders(order_id,cust_id,order_date,order_status) VALUES
 (1, 1, '2024-06-12 14:30:00',1),
 (2, 2, '2024-06-12 15:00:00',1);

 CREATE TABLE order_items (
  order_item_id INT(50) NOT NULL AUTO_INCREMENT,
  order_id INT(50) NOT NULL,
  dishes_id INT(50) NOT NULL,
  quantity INT(50) NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  PRIMARY KEY (order_item_id),
  FOREIGN KEY (order_id) REFERENCES orders(order_id),
  FOREIGN KEY (dishes_id) REFERENCES dishes(dishes_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



CREATE TABLE reviews (
  review_id INT(50) NOT NULL AUTO_INCREMENT,
  cust_id INT(50) NOT NULL,
  dishes_id INT(50) NOT NULL,
  rating INT(1) NOT NULL,
  review TEXT NOT NULL,
  review_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (review_id),
  FOREIGN KEY (cust_id) REFERENCES customer(cust_id),
  FOREIGN KEY (dishes_id) REFERENCES dishes(dishes_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO reviews (cust_id, dishes_id, rating, review, review_date) VALUES
(1, 1, 5, 'These Yorkshire Lamb Patties are amazing! They melt in your mouth and pair perfectly with a crisp salad.', '2024-06-01 10:00:00'),
(2, 2, 4, 'The Manchurian Chicken is flavorful and tender. I loved the sauce, though it could use a bit more spice.', '2024-06-02 11:00:00'),
(1, 3, 5, 'The Chicken Madeira is absolutely delicious! The combination of chicken, mushrooms, and fortified wine is perfect.', '2024-06-03 12:00:00'),
(2, 4, 3, 'The Stuffed Jacket Potatoes are good but a bit too oily for my liking. Still, tasty and satisfying.', '2024-06-04 13:00:00'),
(1, 5, 4, 'Pink Spaghetti Gamberoni was delicious! The prawns and tomato sauce were a great combination.', '2024-06-05 14:00:00'),
(2, 6, 5, 'The Cheesy Mashed Potato is so creamy and fluffy. Perfect side dish to any main course.', '2024-06-06 15:00:00');



CREATE TABLE payment_details (
  payment_id INT(50) NOT NULL AUTO_INCREMENT,
  order_id INT(50) NOT NULL,
  payment_image VARCHAR(255) NOT NULL,
  upload_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  payment_type ENUM('cash', 'online') NOT NULL,
  
  PRIMARY KEY (payment_id),
  FOREIGN KEY (order_id) REFERENCES orders(order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
ALTER TABLE payment_details
ADD COLUMN payment_status ENUM('completed', 'pending', 'failed') NOT NULL AFTER payment_type;

