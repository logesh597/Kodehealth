<?php
require_once('../config.php');
Class Master extends DBConnection {
	private $settings;
	public function __construct(){
		global $_settings;
		$this->settings = $_settings;
		parent::__construct();
	}
	public function __destruct(){
		parent::__destruct();
	}
	function capture_err(){
		if(!$this->conn->error)
			return false;
		else{
			$resp['status'] = 'failed';
			$resp['error'] = $this->conn->error;
			return json_encode($resp);
			exit;
		}
	}
	function save_doctors() {
		extract($_POST);
		$data = "";
		$resp = ['status' => 'failed', 'msg' => 'An error occurred']; // Default response
	
		// Prepare SQL data from POST variables
		foreach ($_POST as $k => $v) {
			if (!in_array($k, ['doctors_id', 'doctors_image'])) {
				$data .= (empty($data) ? "" : ", ") . " {$k}='" . $this->conn->real_escape_string($v) . "' ";
			}
		}
	
		// Log incoming POST data
		error_log("POST data for doctors: " . print_r($_POST, true));
	
		// Handle image upload
		if (isset($_FILES['doctors_image']) && $_FILES['doctors_image']['tmp_name'] != '') {
			$ext = pathinfo($_FILES['doctors_image']['name'], PATHINFO_EXTENSION);
			$fname = "uploads/" . md5(time() . rand()) . ".$ext";
			$accept = ['image/jpeg', 'image/png'];
	
			// Validate file type
			if (!in_array($_FILES['doctors_image']['type'], $accept)) {
				$resp['msg'] = "Invalid image file type: " . $_FILES['doctors_image']['type'];
				error_log($resp['msg']);
				return json_encode($resp);
			}
	
			// Delete old image if exists
			if (!empty($_POST['doctors_image']) && is_file(base_app . $_POST['doctors_image'])) {
				unlink(base_app . $_POST['doctors_image']);
			}
	
			// Move the uploaded image
			if (move_uploaded_file($_FILES['doctors_image']['tmp_name'], base_app . $fname)) {
				$data .= ", doctors_image = '{$fname}' ";
			} else {
				$resp['msg'] = "Failed to upload image";
				error_log($resp['msg']);
				return json_encode($resp);
			}
		}
	
		// Determine if it’s an insert or update
		if (empty($doctors_id)) {
			$sql = "INSERT INTO `doctors` SET {$data}";
		} else {
			$sql = "UPDATE `doctors` SET {$data} WHERE doctors_id = '{$this->conn->real_escape_string($doctors_id)}'";
		}
	
		// Log and execute the query
		error_log("SQL query for doctors: $sql");
		$save = $this->conn->query($sql);
	
		if ($save) {
			$resp['status'] = 'success';
			$resp['msg'] = empty($doctors_id) ? "Doctor details successfully added." : "Doctor details successfully updated.";
		} else {
			$resp['msg'] = "SQL Error: " . $this->conn->error;
			error_log($resp['msg']);
		}
	
		return json_encode($resp);
	}
	

    function delete_doctors() {
		extract($_POST);
		$resp = ['status' => 'failed', 'msg' => 'An error occurred']; // Default response
	
		// Validate ID
		if (empty($id)) {
			$resp['msg'] = "Invalid Doctor ID";
			return json_encode($resp);
		}
	
		// Execute delete query
		$del = $this->conn->query("DELETE FROM `doctors` WHERE doctors_id = '{$this->conn->real_escape_string($id)}'");
		if ($del) {
			$resp['status'] = 'success';
		} else {
			$resp['msg'] = "SQL Error: " . $this->conn->error;
			error_log($resp['msg']);
		}
	
		return json_encode($resp);
	}
	

    function save_dishes() {
		extract($_POST);
		$data = "";
		$resp = ['status' => 'failed', 'msg' => 'An error occurred']; // Default response
	
		// Prepare SQL data from POST variables
		foreach ($_POST as $k => $v) {
			if (!in_array($k, ['dishes_id', 'dishes_image'])) {
				$data .= (empty($data) ? "" : ", ") . " {$k}='" . $this->conn->real_escape_string($v) . "' ";
			}
		}
	
		// Handle image upload
		if (isset($_FILES['dishes_image']) && $_FILES['dishes_image']['tmp_name'] != '') {
			$ext = pathinfo($_FILES['dishes_image']['name'], PATHINFO_EXTENSION);
			$fname = "uploads/" . md5(time() . rand()) . ".$ext";
			$accept = ['image/jpeg', 'image/png'];
	
			// Validate file type
			if (!in_array($_FILES['dishes_image']['type'], $accept)) {
				$resp['msg'] = "Invalid image file type: " . $_FILES['dishes_image']['type'];
				return json_encode($resp);
			}
	
			// Delete existing image if provided
			if (!empty($_POST['dishes_image']) && is_file(base_app . $_POST['dishes_image'])) {
				unlink(base_app . $_POST['dishes_image']);
			}
	
			// Upload new image
			if (move_uploaded_file($_FILES['dishes_image']['tmp_name'], base_app . $fname)) {
				$data .= ", dishes_image = '{$fname}' ";
			} else {
				$resp['msg'] = "Failed to upload image";
				return json_encode($resp);
			}
		}
	
		// Check if it's an insert or update
		if (empty($dishes_id)) {
			$sql = "INSERT INTO `dishes` SET {$data}";
		} else {
			$sql = "UPDATE `dishes` SET {$data} WHERE dishes_id = '{$this->conn->real_escape_string($dishes_id)}'";
		}
	
		// Execute query
		$save = $this->conn->query($sql);
	
		if ($save) {
			$resp['status'] = 'success';
			$resp['msg'] = empty($dishes_id) ? "Dish successfully added." : "Dish successfully updated.";
		} else {
			$resp['msg'] = "SQL Error: " . $this->conn->error;
		}
	
		return json_encode($resp);
	}
	

    function delete_dishes() {
    extract($_POST);
    $resp = ['status' => 'failed', 'msg' => 'An error occurred']; // Default response

    // Validate ID
    if (empty($id)) {
        $resp['msg'] = "Invalid dish ID";
        return json_encode($resp);
    }

    // Delete dish image (optional, if you store image paths in the database)
    $image_query = $this->conn->query("SELECT dishes_image FROM `dishes` WHERE dishes_id = '{$this->conn->real_escape_string($id)}'");
    if ($image_query && $image_query->num_rows > 0) {
        $image = $image_query->fetch_assoc()['dishes_image'];
        if (!empty($image) && is_file(base_app . $image)) {
            unlink(base_app . $image);
        }
    }

    // Execute delete query
    $del = $this->conn->query("DELETE FROM `dishes` WHERE dishes_id = '{$this->conn->real_escape_string($id)}'");
    if ($del) {
        $resp['status'] = 'success';
        $resp['msg'] = "Dish successfully deleted.";
    } else {
        $resp['msg'] = "SQL Error: " . $this->conn->error;
    }

    return json_encode($resp);
}
	
	function save_service(){
		extract($_POST);
		$data = "";
		foreach($_POST as $k => $v){
			if(!in_array($k, array('service_id'))){
				if(!is_numeric($v))
					$v = $this->conn->real_escape_string($v);
				if(!empty($data)) $data .=",";
				$data .= " `{$k}`='{$v}' ";
			}
		}
	
		// Check if service_id is empty (insert) or not (update)
		if(empty($service_id)){
			$sql = "INSERT INTO `service_list` SET {$data}";
		} else {
			$sql = "UPDATE `service_list` SET {$data} WHERE service_id = '{$service_id}'";
		}
	
		// Check for existing service name to prevent duplicates
		$check = $this->conn->query("SELECT * FROM `service_list` WHERE `service_name`='{$service_name}' ".($service_id > 0 ? " AND service_id != '{$service_id}'" : ""))->num_rows;
		if($check > 0){
			$resp['status'] = 'failed';
			$resp['msg'] = "Service Name Already Exists.";
		} else {
			$save = $this->conn->query($sql);
			if($save){
				$rid = !empty($service_id) ? $service_id : $this->conn->insert_id;
				$resp['status'] = 'success';
				if(empty($service_id))
					$resp['msg'] = "Service details were successfully added.";
				else
					$resp['msg'] = "Service details were successfully updated.";
			} else {
				$resp['status'] = 'failed';
				$resp['msg'] = "An error occurred.";
				$resp['err'] = $this->conn->error."[{$sql}]";
			}
		}
	
		// Set a flash message if the save was successful
		if($resp['status'] == 'success')
			$this->settings->set_flashdata('success', $resp['msg']);
		
		return json_encode($resp);
	}
	
	function delete_service(){
		extract($_POST);
		$del = $this->conn->query("DELETE FROM `service_list` where service_id = '{$id}'");
		if($del){
			$resp['status'] = 'success';
			$this->settings->set_flashdata('success',"Service has successfully deleted.");
		}else{
			$resp['status'] = 'failed';
			$resp['error'] = $this->conn->error;
		}
		return json_encode($resp);

	}
	function save_appointment(){
		extract($_POST);
		$data = "";
		foreach($_POST as $k =>$v){
			if(!in_array($k,array('id')) && !is_array($_POST[$k])){
				if(!is_numeric($v))
					$v = $this->conn->real_escape_string($v);
				if(!empty($data)) $data .=",";
				$data .= " `{$k}`='{$v}' ";
			}
		}
		if(empty($id)){
			$sql = "INSERT INTO `appointment_list` set {$data} ";
		}else{
			$sql = "UPDATE `appointment_list` set {$data} where id = '{$id}' ";
		}
		$save = $this->conn->query($sql);
		if($save){
			$aid = !empty($id) ? $id : $this->conn->insert_id;
			$resp['status'] = 'success';
			if(empty($id))
				$resp['msg'] = "Appointment was successfully submit.";
			else
				$resp['msg'] = "Appointmentdetails was successfully updated.";
			$data = "";
			foreach($service_id as $k=> $v){
				if(!empty($data)) $data .= ", ";
				$data .= "('$aid', '{$v}', '{$cost[$k]}')";
			}
			if(!empty($data)){
				$this->conn->query("DELETE FROM `Appointment_service` where `appointment_id` = '$aid'");
				$save = $this->conn->query("INSERT INTO `Appointment_service` (`appointment_id`, `service_id`, `cost`) VALUES {$data} ");
			}
		}else{
			$resp['status'] = 'failed';
			$resp['msg'] = "An error occured.";
			$resp['err'] = $this->conn->error."[{$sql}]";
		}
		if($resp['status'] =='success')
		$this->settings->set_flashdata('success',$resp['msg']);
		return json_encode($resp);
	}
	function delete_appointment(){
		extract($_POST);
		$del = $this->conn->query("DELETE FROM `appointment_list` where appointment_id = '{$id}'");
		if($del){
			$resp['status'] = 'success';
			$this->settings->set_flashdata('success',"Appointmenthas successfully deleted.");
		}else{
			$resp['status'] = 'failed';
			$resp['error'] = $this->conn->error;
		}
		return json_encode($resp);
	}
	function verify_appointment(){
		extract($_POST);
		$notification_message = "Your appointmenthas been verified.";
		$update = $this->conn->query("UPDATE `appointment_list` SET `status` = 1, `notification_status` = 1, `notification_message` = '{$notification_message}' WHERE `appointment_id` = '{$id}'");
		if($update){
			$resp['status'] = 'success';
			$this->settings->set_flashdata('success',"Appointmenthas successfully verified.");
		}else{
			$resp['status'] = 'failed';
			$resp['error'] = $this->conn->error;
		}
		return json_encode($resp);
	}
	function reject_appointment(){
        extract($_POST);
		$notification_message = "Your appointmenthas been rejected.";
		$update = $this->conn->query("UPDATE `appointment_list` SET `status` = 3, `notification_status` = 1, `notification_message` = '{$notification_message}' WHERE `appointment_id` = '{$id}'");
		if($update){
			$resp['status'] = 'success';
			$this->settings->set_flashdata('success',"Appointmenthas successfully rejected.");
		}else{
			$resp['status'] = 'failed';
			$resp['error'] = $this->conn->error;
		}
		return json_encode($resp);
    }
	
    
}

$Master = new Master();
$action = !isset($_GET['f']) ? 'none' : strtolower($_GET['f']);
$sysset = new SystemSettings();
switch ($action) {
	case 'save_service':
		echo $Master->save_service();
	break;
	case 'delete_service':
		echo $Master->delete_service();
	break;
	case 'save_appointment':
		echo $Master->save_appointment();
	break;
	case 'delete_appointment':
		echo $Master->delete_appointment();
	break;
	case 'verify_appointment':
		echo $Master->verify_appointment();
	break;
	case 'reject_appointment':
		echo $Master->reject_appointment();
	break;
	case 'save_doctors':
        echo $Master->save_doctors();
        break;
    case 'delete_doctors':
        echo $Master->delete_doctors();
        break;
    case 'save_dishes':
        echo $Master->save_dishes();	
        break;
    case 'delete_dishes':
        echo $Master->delete_dishes();
        break;
	
	
	default:
		// echo $sysset->index();
		break;
}