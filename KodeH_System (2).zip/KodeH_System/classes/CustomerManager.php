<?php
require_once('../config.php');
Class CustomerManager extends DBConnection {
    private $settings;
    public function __construct(){
        global $_settings;
        $this->settings = $_settings;
        parent::__construct();
    }
    public function __destruct(){
        parent::__destruct();
    }

    public function save_customer(){
        extract($_POST);
        $data = "";
        foreach($_POST as $k => $v){
            if(!empty($data)) $data .= ", ";
            $data .= " `{$k}` = '{$v}' ";
        }

        if(empty($cust_id)){
            $sql = "INSERT INTO `customer` set {$data}";
        }else{
            $sql = "UPDATE `customer` set {$data} where cust_id = '{$cust_id}'";
        }

        $save = $this->conn->query($sql);
        if($save){
            $resp['status'] = 'success';
            if(empty($cust_id))
                $resp['msg'] = "Customer has successfully added.";
            else
                $resp['msg'] = "Customer has been updated successfully.";
        }else{
            $resp['status'] = 'failed';
            $resp['msg'] = $this->conn->error;
        }

        return json_encode($resp);
    }

    public function delete_customer(){
        extract($_POST);
        $del = $this->conn->query("DELETE FROM `customer` where cust_id = '{$id}'");
        if($del){
            $resp['status'] = 'success';
            $resp['msg'] = "Customer has been deleted successfully.";
        }else{
            $resp['status'] = 'failed';
            $resp['msg'] = $this->conn->error;
        }
        return json_encode($resp);
    }
}

$CustomerManager = new CustomerManager();
$action = !isset($_GET['f']) ? 'none' : strtolower($_GET['f']);
switch ($action) {
    case 'save_customer':
        echo $CustomerManager->save_customer();
    break;
    case 'delete_customer':
        echo $CustomerManager->delete_customer();
    break;
    default:
        // echo $sysset->index();
    break;
}
?>
