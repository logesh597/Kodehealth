<?php
// Start the session
session_start();

// Check if the customer is logged in
if (!isset($_SESSION['cust_id'])) {
    header("Location: customer_login.php"); // Redirect to login page if not logged in
    exit();
}

// Database connection
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "hss_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if appointment_id is set in POST request
if (isset($_POST['appointment_id'])) {
    $appointment_id = $_POST['appointment_id'];
    $cust_id = $_SESSION['cust_id'];

    // Update the notification status to 0 (deleted)
    $sql = "UPDATE appointment_list SET notification_status = 0 WHERE appointment_id = $appointment_id AND cust_id = $cust_id";

    if ($conn->query($sql) === TRUE) {
        // Success, redirect back to the notification page
        header("Location: notification.php");
        exit();
    } else {
        echo "Error deleting notification: " . $conn->error;
    }
} else {
    echo "Invalid request.";
}

$conn->close();
?>
