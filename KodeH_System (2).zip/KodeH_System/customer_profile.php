<?php
// Include the configuration file which starts the session
require_once('./config.php');
require_once('inc/header.php');

// Check if the session variable is set
if (!isset($_SESSION['cust_id'])) {
    // Use JavaScript to redirect to the login page
    echo '<script type="text/javascript">
            window.location = "customer_login.php";
          </script>';
    exit();
}

// Retrieve customer details
$cust_id = $_SESSION['cust_id'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hss_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch customer details
$stmt = $conn->prepare("SELECT cust_name, cust_email, cust_contact FROM customer WHERE cust_id = ?");
$stmt->bind_param("i", $cust_id);
$stmt->execute();
$stmt->bind_result($cust_name, $cust_email, $cust_contact);
$stmt->fetch();
$stmt->close();

// Fetch appointments
$appointments = [];
$appt_stmt = $conn->prepare("SELECT a.schedule_date, a.schedule_time, s.doctors_name, a.status 
                             FROM appointment_list a 
                             JOIN doctors s ON a.doctors_id = s.doctors_id 
                             WHERE a.cust_id = ?");
$appt_stmt->bind_param("i", $cust_id);
$appt_stmt->execute();
$appt_result = $appt_stmt->get_result();
while ($row = $appt_result->fetch_assoc()) {
    $appointments[] = $row;
}
$appt_stmt->close();


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Customer Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 100px;
        }
        .container {
            max-width: 1000px;
            margin: 0 auto;
        }
        .section {
            margin-bottom: 30px;
        }
        .section h2 {
            margin-bottom: 10px;
        }
        .accordion {
            cursor: pointer;
            background-color: #f2f2f2;
            padding: 10px;
            border: none;
            outline: none;
            width: 100%;
            text-align: left;
            font-size: 16px;
            transition: background-color 0.2s ease;
        }
        .accordion:hover {
            background-color: #ddd;
        }
        .panel {
            padding: 0 18px;
            background-color: white;
            display: none;
            overflow: hidden;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #2b1d01; /* Header background color */
            color: white;
        }
        tr:nth-child(even) {
        background-color: #2b1d01; /* Even row background color */
        }
        tr:nth-child(odd) {
            background-color: #2b1d01; /* Odd row background color */
        }
        .order-status {
            font-weight: bold;
        }
        .order-status.pending {
            color: #1E90FF; /* DodgerBlue */
        }
        .order-status.completed {
            color: #4682B4; /* SteelBlue */
        }
        .appointment-status.pending {
        color: #FFA500; /* Orange for Pending */
        }
        .appointment-status.verified {
            color: #32CD32; /* LimeGreen for Verified */
        }
        .appointment-status.rejected {
            color: #FF4500; /* OrangeRed for Rejected */
        }
    </style>
</head>
<body class="layout-top-nav layout-fixed layout-navbar-fixed dark-mode text-light" style="height: auto;">
    <div class="wrapper">
        <?php require_once('inc/topBarNav.php'); ?>  <!-- Include navigation bar -->
        <div class="container">
            <h1>My Profile</h1>
            <div class="section">
                <p><strong><br>Name:</strong> <?php echo $cust_name; ?></p>
                <p><strong>Email:</strong> <?php echo $cust_email; ?></p>
                <p><strong>Contact Number:</strong> <?php echo $cust_contact; ?></p>
            </div>

            <div class="section">
                <h2>Appointments</h2>
                <?php if (count($appointments) > 0): ?>
                    <table>
                        <tr>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Doctor Name</th>
                            <th>Status</th>
                        </tr>
                        <?php foreach ($appointments as $appointment): ?>
    <tr>
        <td><?php echo $appointment['schedule_date']; ?></td>
        <td><?php echo $appointment['schedule_time']; ?></td>
        <td><?php echo $appointment['doctors_name']; ?></td>
        <td class="appointment-status <?php echo strtolower($appointment['status'] == '0' ? 'pending' : ($appointment['status'] == '1' ? 'verified' : 'rejected')); ?>">
            <?php 
            switch($appointment['status']){
                case '0':
                    echo 'Pending';
                    break;
                case '1':
                    echo 'Verified';
                    break;
                case '3':
                    echo 'Rejected';
                    break;
                default:
                    echo 'Unknown';
                    break;
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                    </table>
                <?php else: ?>
                    <p>No appointments found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div> <!-- End wrapper -->
<script>
    var acc = document.getElementsByClassName("accordion");
    var i;

    for (i = 0; i < acc.length; i++) {
        acc[i].addEventListener("click", function() {
            this.classList.toggle("active");
            var panel = this.nextElementSibling;
            if (panel.style.display === "block") {
                panel.style.display = "none";
            } else {
                panel.style.display = "block";
            }
        });
    }
</script>
</body>
<html>