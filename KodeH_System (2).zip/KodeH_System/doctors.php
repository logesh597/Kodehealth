<?php
require_once('./config.php'); // Include database connection file

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables for filtering
$filter_position = '';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve selected position from form
    $filter_position = $_POST['position'];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stylists List</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .doctors-card {
            text-align: center;
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 20px;
            background-color: #ff148f3;
            height: 100%; /* Ensures all cards are of equal height */
        }
        .doctors-card img {
            max-width: 100%;
            height: 200px; /* Fixed height for stylist images */
            object-fit: cover; /* Ensures the image covers the frame */
            border-radius: 50%;
            margin-bottom: 15px;
        }
        .doctors-card h3 {
            margin-top: 10px;
            font-size: 1.5rem;
        }
        .doctors-card p {
            font-size: 1rem;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Doctors List</h2>

        <!-- Filter form -->
        <form method="POST" class="mb-4">
            <div class="form-group">
                <label for="position">Filter by Position:</label>
                <select name="position" id="position" class="form-control">
                    <option value="">All Positions</option>
                    <option value="Junior Doctort" <?php if ($filter_position == 'Junior Doctor') echo 'selected'; ?>>Junior Doctor</option>
                    <option value="Senior Doctor" <?php if ($filter_position == 'Senior Doctor') echo 'selected'; ?>>Senior Doctor</option>
                    <option value="Master Doctor" <?php if ($filter_position == 'Master Doctor') echo 'selected'; ?>>Master Doctor</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Filter</button>
        </form>

        <div class="row">
            <?php 
            // Build SQL query based on selected filter
            $sql = "SELECT * FROM `doctors`";
            if (!empty($filter_position)) {
                $sql .= " WHERE `doctors_position` = '" . $conn->real_escape_string($filter_position) . "'";
            }
            $sql .= " ORDER BY `doctors_name` ASC";

            $stylists = $conn->query($sql);

            if ($stylists && $stylists->num_rows > 0) {
                while ($row = $stylists->fetch_assoc()):
            ?>
                <div class="col-md-4">
                    <div class="doctors-card">
                        <img src="<?= htmlspecialchars($row['doctors_image']) ?>" alt="<?= htmlspecialchars($row['doctors_name']) ?>">
                        <h3><?= htmlspecialchars($row['doctors_name']) ?></h3>
                        <p><strong>Position:</strong> <?= htmlspecialchars($row['doctors_position']) ?></p>
                        <p><strong>Description:</strong> <?= htmlspecialchars($row['doctors_description']) ?></p>
                    </div>
                </div>
            <?php 
                endwhile;
            } else {
                echo "<div class='col text-center'><p>No doctors found.</p></div>";
            }
            ?>
        </div>
    </div>
</body>
</html>
